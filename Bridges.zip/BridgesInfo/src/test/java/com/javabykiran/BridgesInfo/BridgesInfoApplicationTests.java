package com.javabykiran.BridgesInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BridgesInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
