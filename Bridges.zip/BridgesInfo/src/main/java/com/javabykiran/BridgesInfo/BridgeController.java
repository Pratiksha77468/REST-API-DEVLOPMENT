package com.javabykiran.BridgesInfo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javabykiran.extra.Extra;

@RestController
public class BridgeController {
	@Autowired
	@Qualifier("createBean")                  //@Bean method call here
	Extra ee = null;
	
	
	@Value("${bridgeCost}")
	 int bridgeCost;
	
	@Autowired
	X xx = null;
	
	@Autowired                         //it inject the object dependency in bean
	BridgeService service = null ;
	
	
	@GetMapping("checkobjectcreation")
	public void learnIOC() {	
		System.out.println("Bridgecost= "+bridgeCost);
		xx.m2();
		
	}
	
	@GetMapping("bridgescount")
	int noOfBridgesinIndia(){
		
		return 1236;
	}
	@PostMapping("addbridgeinfo")
	public void addBridge(@RequestBody Bridge bridge) {
		System.out.println("Bridge info........."+bridge);
		//System.out.println("Cost of Bridge is "+bridgeCost);
		//jdbc to insert into database
	}
	
	@RequestMapping("bridgeinfo")
	Bridge fetchBridgeInfo(){
		//class.forname
		//select star from Bridge..column;
		Bridge bridge = new Bridge("pune",11,"500mtr","40mtr");
		return bridge;
		
	}
	@RequestMapping("bridgesInformation")
	ArrayList<Bridge> fetchBridgesInfo(){
		//BridgeService service = new BridgeService();
		ArrayList<Bridge> alBridges = service.fetchBridgesInfo();
		return alBridges ;
		
	}
	
	
	
	
	
	@RequestMapping("bridgesName/{cityname}")
	ArrayList<String> nameofBridgesinCity(@PathVariable String cityname){
		System.out.println("I am in nameofBridgesinCity" +cityname);
		ArrayList<String> listBridges = new ArrayList<>();
		listBridges.add("Z bridge");
		listBridges.add("Pawale bridge");
		listBridges.add("Navale bridge");
		listBridges.add("Warje bridge");
		listBridges.add("Dandekar bridge");
		listBridges.add("Tata bridge");
		
		return listBridges;
	}
}
