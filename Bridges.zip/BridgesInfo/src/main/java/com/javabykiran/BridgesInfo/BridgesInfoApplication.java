
package com.javabykiran.BridgesInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Primary;

import com.javabykiran.extra.Extra;

@SpringBootApplication
@ComponentScan("com")
public class BridgesInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BridgesInfoApplication.class, args);
	}
	
	@Bean
	//@Primary
	Extra createBean() {
		System.err.println("Extra bean creation");
		return new Extra();
		
	}
}
