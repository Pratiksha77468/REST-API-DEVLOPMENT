package com.javabykiran.BridgesInfo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


//@Component
@Service
public class BridgeService {
	
	@Autowired
	BridgeDao dao =null;
	
	
	public ArrayList<Bridge> fetchBridgesInfo(){
	
	ArrayList<Bridge> bridgeList = dao.fetchBridgesInfo();
	return bridgeList;
}
}
