package com.javabykiran.BridgesInfo;

import org.springframework.stereotype.Component;

@Component
public class X {

	public X() {
		super();
		System.err.println("I am in constructor");
	}
	public void m2() {
		System.err.println("X ...........I am in m2");
	}
	
}
