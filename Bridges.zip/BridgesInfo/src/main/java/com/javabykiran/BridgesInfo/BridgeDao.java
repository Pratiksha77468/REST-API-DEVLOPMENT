package com.javabykiran.BridgesInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component
@Repository
public class BridgeDao {

	ArrayList<Bridge>  fetchBridgesInfo(){
		ArrayList<Bridge> alBridgesList = new ArrayList<Bridge>();
		
	
	try {
		System.out.println(1);
		//loading a class
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(2);
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","pradip");
		System.out.println(3);
		String sql = "select * from bridge";
		System.out.println(4);
		Statement statement = connection.createStatement();
		System.out.println(5);
		ResultSet resultSet = statement.executeQuery(sql);
		
		
		while(resultSet.next()) {
			int bridgeNumber = resultSet.getInt(1);
			String bridgeCity = resultSet.getString(2);
			String bridgeLength = resultSet.getString(3);
			String bridgeWidth = resultSet.getString(4);
			
			Bridge bridge = new Bridge(bridgeCity,bridgeNumber,bridgeLength,bridgeWidth);
			/*System.out.println("bridgeNumber=" +bridgeNumber);
			System.out.println("bridgeCity=" +bridgeCity);
			System.out.println("bridgeLength=" +bridgeLength);
			System.out.println("bridgeWidth=" +bridgeWidth);*/
			
			alBridgesList.add(bridge);
		}
		
	}
	catch(Exception e) {
		
		e.printStackTrace();
		
	}
	
	
	return alBridgesList;
	}
}



