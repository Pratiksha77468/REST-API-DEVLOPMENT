package com.javabykiran.extra;

import org.springframework.stereotype.Component;

@Component
public class Extra {

	public Extra() {
		super();
		//System.err.println("Extra constructor");
	}
	public void show() {
		System.err.println("I am in extra class method");
	}
	
}
